# windows service to start python app

# WinPython

WPy64-3830 is the folder of WinPython portable environment

# start_winpy_app_service.bat

This bat file should be in "../pyapp/" folder and start python app.

# pyapp 

http://gitlabsvr/Repos/CS/InnoLab/Card/pyapp.git
